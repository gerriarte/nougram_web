import { Project, Service, Cost, TeamMember, Currency, Tax, User } from './types';

// Mock Projects Data
export const mockProjects: Project[] = [
  {
    id: '1',
    name: 'Website Redesign for Tech Corp',
    client: 'Tech Corp Solutions',
    clientEmail: 'contact@techcorp.com',
    status: 'won',
    currency: 'USD',
    subtotal: 45000,
    taxes: 9000,
    total: 54000,
    margin: 35,
    createdAt: new Date('2024-11-15'),
    updatedAt: new Date('2024-12-01'),
    services: []
  },
  {
    id: '2',
    name: 'Mobile App Development',
    client: 'Startup Innovations',
    clientEmail: 'team@startup.io',
    status: 'sent',
    currency: 'USD',
    subtotal: 85000,
    taxes: 17000,
    total: 102000,
    margin: 42,
    createdAt: new Date('2024-12-05'),
    updatedAt: new Date('2024-12-10'),
    services: []
  },
  {
    id: '3',
    name: 'Brand Identity Package',
    client: 'Creative Studios LLC',
    clientEmail: 'hello@creativestudios.com',
    status: 'draft',
    currency: 'USD',
    subtotal: 12000,
    taxes: 2400,
    total: 14400,
    margin: 28,
    createdAt: new Date('2024-12-10'),
    updatedAt: new Date('2024-12-12'),
    services: []
  },
  {
    id: '4',
    name: 'E-commerce Platform',
    client: 'Retail Giants Inc',
    clientEmail: 'projects@retailgiants.com',
    status: 'sent',
    currency: 'USD',
    subtotal: 125000,
    taxes: 25000,
    total: 150000,
    margin: 38,
    createdAt: new Date('2024-11-20'),
    updatedAt: new Date('2024-12-08'),
    services: []
  },
  {
    id: '5',
    name: 'Marketing Campaign',
    client: 'Fashion Forward',
    clientEmail: 'marketing@fashionforward.com',
    status: 'lost',
    currency: 'USD',
    subtotal: 32000,
    taxes: 6400,
    total: 38400,
    margin: 25,
    createdAt: new Date('2024-10-15'),
    updatedAt: new Date('2024-11-10'),
    services: []
  },
  {
    id: '6',
    name: 'CRM System Integration',
    client: 'Enterprise Solutions',
    clientEmail: 'it@enterprise.com',
    status: 'won',
    currency: 'USD',
    subtotal: 68000,
    taxes: 13600,
    total: 81600,
    margin: 40,
    createdAt: new Date('2024-11-01'),
    updatedAt: new Date('2024-11-25'),
    services: []
  },
  {
    id: '7',
    name: 'Social Media Strategy',
    client: 'Lifestyle Brands Co',
    clientEmail: 'social@lifestylebrands.com',
    status: 'draft',
    currency: 'USD',
    subtotal: 18000,
    taxes: 3600,
    total: 21600,
    margin: 32,
    createdAt: new Date('2024-12-11'),
    updatedAt: new Date('2024-12-13'),
    services: []
  },
  {
    id: '8',
    name: 'Product Photography',
    client: 'Artisan Goods',
    clientEmail: 'info@artisangoods.com',
    status: 'sent',
    currency: 'USD',
    subtotal: 8500,
    taxes: 1700,
    total: 10200,
    margin: 45,
    createdAt: new Date('2024-12-08'),
    updatedAt: new Date('2024-12-11'),
    services: []
  }
];

// Mock Services
export const mockServices: Service[] = [
  { id: '1', name: 'UI/UX Design', defaultHourlyRate: 120, category: 'Design' },
  { id: '2', name: 'Frontend Development', defaultHourlyRate: 140, category: 'Development' },
  { id: '3', name: 'Backend Development', defaultHourlyRate: 150, category: 'Development' },
  { id: '4', name: 'Project Management', defaultHourlyRate: 130, category: 'Management' },
  { id: '5', name: 'Quality Assurance', defaultHourlyRate: 100, category: 'Testing' },
  { id: '6', name: 'DevOps', defaultHourlyRate: 160, category: 'Infrastructure' },
  { id: '7', name: 'Brand Strategy', defaultHourlyRate: 135, category: 'Strategy' },
  { id: '8', name: 'Content Writing', defaultHourlyRate: 80, category: 'Content' },
  { id: '9', name: 'SEO Optimization', defaultHourlyRate: 110, category: 'Marketing' },
  { id: '10', name: 'Social Media Management', defaultHourlyRate: 90, category: 'Marketing' }
];

// Mock Costs
export const mockCosts: Cost[] = [
  { id: '1', name: 'Senior Developer', category: 'Development', hourlyRate: 90, isActive: true },
  { id: '2', name: 'Mid-Level Developer', category: 'Development', hourlyRate: 60, isActive: true },
  { id: '3', name: 'Junior Developer', category: 'Development', hourlyRate: 40, isActive: true },
  { id: '4', name: 'Senior Designer', category: 'Design', hourlyRate: 80, isActive: true },
  { id: '5', name: 'Mid-Level Designer', category: 'Design', hourlyRate: 55, isActive: true },
  { id: '6', name: 'Project Manager', category: 'Management', hourlyRate: 85, isActive: true },
  { id: '7', name: 'QA Specialist', category: 'Testing', hourlyRate: 50, isActive: true },
  { id: '8', name: 'Content Writer', category: 'Content', hourlyRate: 45, isActive: true }
];

// Mock Team Members
export const mockTeamMembers: TeamMember[] = [
  { id: '1', name: 'Sarah Johnson', role: 'Senior Developer', email: 'sarah@agenciaops.com', costId: '1' },
  { id: '2', name: 'Michael Chen', role: 'UI/UX Designer', email: 'michael@agenciaops.com', costId: '4' },
  { id: '3', name: 'Emily Rodriguez', role: 'Project Manager', email: 'emily@agenciaops.com', costId: '6' },
  { id: '4', name: 'David Kim', role: 'Backend Developer', email: 'david@agenciaops.com', costId: '2' },
  { id: '5', name: 'Lisa Wang', role: 'Frontend Developer', email: 'lisa@agenciaops.com', costId: '2' },
  { id: '6', name: 'James Miller', role: 'QA Specialist', email: 'james@agenciaops.com', costId: '7' }
];

// Mock Currencies
export const mockCurrencies: Currency[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$' },
  { code: 'EUR', name: 'Euro', symbol: '€' },
  { code: 'GBP', name: 'British Pound', symbol: '£' },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
  { code: 'MXN', name: 'Mexican Peso', symbol: 'MX$' }
];

// Mock Taxes
export const mockTaxes: Tax[] = [
  { id: '1', name: 'Standard VAT (20%)', rate: 20, isDefault: true },
  { id: '2', name: 'Reduced VAT (10%)', rate: 10, isDefault: false },
  { id: '3', name: 'Sales Tax (8.5%)', rate: 8.5, isDefault: false },
  { id: '4', name: 'No Tax', rate: 0, isDefault: false }
];

// Mock Users
export const mockUsers: User[] = [
  { id: '1', name: 'Alex Thompson', email: 'alex@agenciaops.com', role: 'admin' },
  { id: '2', name: 'Sarah Johnson', email: 'sarah@agenciaops.com', role: 'manager' },
  { id: '3', name: 'Michael Chen', email: 'michael@agenciaops.com', role: 'member' },
  { id: '4', name: 'Emily Rodriguez', email: 'emily@agenciaops.com', role: 'manager' },
  { id: '5', name: 'David Kim', email: 'david@agenciaops.com', role: 'member' }
];

// Current user
export const currentUser: User = mockUsers[0];
