import { useState } from 'react';
import { Plus, Eye, Pencil, Trash, FolderOpen } from 'lucide-react';
import { Button } from '../ui/button';
import { StatusBadge } from '../StatusBadge';
import { StatusFilterCard } from '../StatusFilterCard';
import { mockProjects } from '../../lib/mock-data';
import { ProjectStatus } from '../../lib/types';

interface ProjectsPageProps {
  onNavigate: (page: string) => void;
}

export function ProjectsPage({ onNavigate }: ProjectsPageProps) {
  const [selectedStatus, setSelectedStatus] = useState<ProjectStatus | 'all'>('all');

  // Filter projects
  const filteredProjects = selectedStatus === 'all' 
    ? mockProjects 
    : mockProjects.filter(p => p.status === selectedStatus);

  // Calculate counts
  const statusCounts = {
    all: mockProjects.length,
    draft: mockProjects.filter(p => p.status === 'draft').length,
    sent: mockProjects.filter(p => p.status === 'sent').length,
    won: mockProjects.filter(p => p.status === 'won').length,
    lost: mockProjects.filter(p => p.status === 'lost').length
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    }).format(date);
  };

  return (
    <div className="space-y-6">
      {/* Header with New Quote Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-grey-900">All Projects</h2>
          <p className="text-grey-600 mt-1">Manage and track your agency quotes</p>
        </div>
        <Button 
          onClick={() => onNavigate('create-quote')}
          className="bg-primary-500 hover:bg-primary-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Quote
        </Button>
      </div>

      {/* Status Filter Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        <StatusFilterCard
          title="All Projects"
          count={statusCounts.all}
          description="Total quotes"
          isActive={selectedStatus === 'all'}
          onClick={() => setSelectedStatus('all')}
        />
        <StatusFilterCard
          title="Draft"
          count={statusCounts.draft}
          description="In progress"
          isActive={selectedStatus === 'draft'}
          onClick={() => setSelectedStatus('draft')}
        />
        <StatusFilterCard
          title="Sent"
          count={statusCounts.sent}
          description="Awaiting response"
          isActive={selectedStatus === 'sent'}
          onClick={() => setSelectedStatus('sent')}
        />
        <StatusFilterCard
          title="Won"
          count={statusCounts.won}
          description="Accepted"
          isActive={selectedStatus === 'won'}
          onClick={() => setSelectedStatus('won')}
        />
        <StatusFilterCard
          title="Lost"
          count={statusCounts.lost}
          description="Declined"
          isActive={selectedStatus === 'lost'}
          onClick={() => setSelectedStatus('lost')}
        />
      </div>

      {/* Projects Table */}
      <div className="bg-white rounded-xl border border-grey-200 overflow-hidden" style={{ boxShadow: 'var(--elevation-2)' }}>
        {filteredProjects.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-grey-50">
                <tr>
                  <th className="px-6 py-4 text-left text-grey-700">Project Name</th>
                  <th className="px-6 py-4 text-left text-grey-700">Client</th>
                  <th className="px-6 py-4 text-left text-grey-700">Status</th>
                  <th className="px-6 py-4 text-left text-grey-700">Total</th>
                  <th className="px-6 py-4 text-left text-grey-700">Margin</th>
                  <th className="px-6 py-4 text-left text-grey-700">Created</th>
                  <th className="px-6 py-4 text-left text-grey-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProjects.map((project) => (
                  <tr 
                    key={project.id} 
                    className="border-t border-grey-200 hover:bg-grey-50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-grey-900">{project.name}</p>
                        <p className="text-grey-600 text-xs mt-0.5">{project.id}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-grey-900">{project.client}</p>
                        {project.clientEmail && (
                          <p className="text-grey-600 text-xs mt-0.5">{project.clientEmail}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge status={project.status} />
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-grey-900">${project.total.toLocaleString()}</p>
                        <p className="text-grey-600 text-xs mt-0.5">{project.currency}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div 
                          className={`px-2 py-1 rounded text-xs ${
                            project.margin >= 40 
                              ? 'bg-success-50 text-success-700' 
                              : project.margin >= 30 
                              ? 'bg-warning-50 text-warning-700' 
                              : 'bg-error-50 text-error-700'
                          }`}
                        >
                          {project.margin}%
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-grey-900">
                      {formatDate(project.createdAt)}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                          <Eye className="w-4 h-4 text-grey-600" />
                        </button>
                        <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                          <Pencil className="w-4 h-4 text-grey-600" />
                        </button>
                        <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                          <Trash className="w-4 h-4 text-error-500" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          /* Empty State */
          <div className="py-16 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-grey-100 mb-4">
              <FolderOpen className="w-8 h-8 text-grey-400" />
            </div>
            <h3 className="text-grey-900 mb-2">No projects found</h3>
            <p className="text-grey-600 mb-6">
              {selectedStatus === 'all' 
                ? "You haven't created any projects yet" 
                : `No projects with status "${selectedStatus}"`}
            </p>
            {selectedStatus === 'all' && (
              <Button 
                onClick={() => onNavigate('create-quote')}
                className="bg-primary-500 hover:bg-primary-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create First Project
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
