import { useState } from 'react';
import { Plus, Pencil, Trash, DollarSign, Users, Package, Coins, Receipt, UserCog } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog';
import { mockCosts, mockServices, mockTeamMembers, mockCurrencies, mockTaxes, mockUsers } from '../../lib/mock-data';

type SettingsSection = 'costs' | 'services' | 'team' | 'currency' | 'taxes' | 'users';

export function SettingsPage() {
  const [activeSection, setActiveSection] = useState<SettingsSection>('costs');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const sections = [
    { id: 'costs' as const, label: 'Costs', icon: DollarSign, description: 'Manage hourly cost rates' },
    { id: 'services' as const, label: 'Services', icon: Package, description: 'Configure service catalog' },
    { id: 'team' as const, label: 'Team', icon: Users, description: 'Manage team members' },
    { id: 'currency' as const, label: 'Currency', icon: Coins, description: 'Set default currency' },
    { id: 'taxes' as const, label: 'Taxes', icon: Receipt, description: 'Configure tax rates' },
    { id: 'users' as const, label: 'Users & Roles', icon: UserCog, description: 'Manage user permissions' }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'costs':
        return (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3>Cost Rates</h3>
                <p className="text-grey-600 mt-1">Define hourly cost rates for accurate margin calculations</p>
              </div>
              <Button 
                onClick={() => setIsDialogOpen(true)}
                className="bg-primary-500 hover:bg-primary-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Cost
              </Button>
            </div>

            <div className="bg-white rounded-xl border border-grey-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-grey-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-grey-700">Name</th>
                    <th className="px-6 py-4 text-left text-grey-700">Category</th>
                    <th className="px-6 py-4 text-left text-grey-700">Hourly Rate</th>
                    <th className="px-6 py-4 text-left text-grey-700">Status</th>
                    <th className="px-6 py-4 text-left text-grey-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockCosts.map((cost) => (
                    <tr key={cost.id} className="border-t border-grey-200 hover:bg-grey-50 transition-colors">
                      <td className="px-6 py-4 text-grey-900">{cost.name}</td>
                      <td className="px-6 py-4 text-grey-700">{cost.category}</td>
                      <td className="px-6 py-4 text-grey-900">${cost.hourlyRate}/hr</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          cost.isActive ? 'bg-success-50 text-success-700' : 'bg-grey-100 text-grey-600'
                        }`}>
                          {cost.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1">
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Pencil className="w-4 h-4 text-grey-600" />
                          </button>
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Trash className="w-4 h-4 text-error-500" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'services':
        return (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3>Services</h3>
                <p className="text-grey-600 mt-1">Manage your service catalog and default rates</p>
              </div>
              <Button 
                onClick={() => setIsDialogOpen(true)}
                className="bg-primary-500 hover:bg-primary-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Service
              </Button>
            </div>

            <div className="bg-white rounded-xl border border-grey-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-grey-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-grey-700">Service Name</th>
                    <th className="px-6 py-4 text-left text-grey-700">Category</th>
                    <th className="px-6 py-4 text-left text-grey-700">Default Rate</th>
                    <th className="px-6 py-4 text-left text-grey-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockServices.map((service) => (
                    <tr key={service.id} className="border-t border-grey-200 hover:bg-grey-50 transition-colors">
                      <td className="px-6 py-4 text-grey-900">{service.name}</td>
                      <td className="px-6 py-4 text-grey-700">{service.category}</td>
                      <td className="px-6 py-4 text-grey-900">${service.defaultHourlyRate}/hr</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1">
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Pencil className="w-4 h-4 text-grey-600" />
                          </button>
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Trash className="w-4 h-4 text-error-500" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'team':
        return (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3>Team Members</h3>
                <p className="text-grey-600 mt-1">Manage your team and assign cost rates</p>
              </div>
              <Button 
                onClick={() => setIsDialogOpen(true)}
                className="bg-primary-500 hover:bg-primary-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Member
              </Button>
            </div>

            <div className="bg-white rounded-xl border border-grey-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-grey-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-grey-700">Name</th>
                    <th className="px-6 py-4 text-left text-grey-700">Role</th>
                    <th className="px-6 py-4 text-left text-grey-700">Email</th>
                    <th className="px-6 py-4 text-left text-grey-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockTeamMembers.map((member) => (
                    <tr key={member.id} className="border-t border-grey-200 hover:bg-grey-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                            <span className="text-primary-700 text-xs">
                              {member.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <span className="text-grey-900">{member.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-grey-700">{member.role}</td>
                      <td className="px-6 py-4 text-grey-700">{member.email}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1">
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Pencil className="w-4 h-4 text-grey-600" />
                          </button>
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Trash className="w-4 h-4 text-error-500" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'currency':
        return (
          <div className="space-y-4">
            <div>
              <h3>Currency Settings</h3>
              <p className="text-grey-600 mt-1">Select your default currency for new quotes</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mockCurrencies.map((curr) => (
                <div 
                  key={curr.code}
                  className="bg-white rounded-xl border border-grey-200 p-6 hover:border-primary-500 cursor-pointer transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl mb-1">{curr.symbol}</div>
                      <h4 className="text-grey-900">{curr.name}</h4>
                      <p className="text-grey-600 text-xs mt-1">{curr.code}</p>
                    </div>
                    {curr.code === 'USD' && (
                      <span className="px-2 py-1 rounded-full bg-primary-500 text-white text-xs">
                        Default
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'taxes':
        return (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3>Tax Rates</h3>
                <p className="text-grey-600 mt-1">Configure tax rates for your quotes</p>
              </div>
              <Button 
                onClick={() => setIsDialogOpen(true)}
                className="bg-primary-500 hover:bg-primary-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Tax Rate
              </Button>
            </div>

            <div className="bg-white rounded-xl border border-grey-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-grey-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-grey-700">Name</th>
                    <th className="px-6 py-4 text-left text-grey-700">Rate</th>
                    <th className="px-6 py-4 text-left text-grey-700">Default</th>
                    <th className="px-6 py-4 text-left text-grey-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockTaxes.map((tax) => (
                    <tr key={tax.id} className="border-t border-grey-200 hover:bg-grey-50 transition-colors">
                      <td className="px-6 py-4 text-grey-900">{tax.name}</td>
                      <td className="px-6 py-4 text-grey-900">{tax.rate}%</td>
                      <td className="px-6 py-4">
                        {tax.isDefault && (
                          <span className="px-2 py-1 rounded-full bg-primary-100 text-primary-700 text-xs">
                            Default
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1">
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Pencil className="w-4 h-4 text-grey-600" />
                          </button>
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Trash className="w-4 h-4 text-error-500" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'users':
        return (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3>Users & Roles</h3>
                <p className="text-grey-600 mt-1">Manage user access and permissions</p>
              </div>
              <Button 
                onClick={() => setIsDialogOpen(true)}
                className="bg-primary-500 hover:bg-primary-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Invite User
              </Button>
            </div>

            <div className="bg-white rounded-xl border border-grey-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-grey-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-grey-700">User</th>
                    <th className="px-6 py-4 text-left text-grey-700">Email</th>
                    <th className="px-6 py-4 text-left text-grey-700">Role</th>
                    <th className="px-6 py-4 text-left text-grey-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockUsers.map((user) => (
                    <tr key={user.id} className="border-t border-grey-200 hover:bg-grey-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary-500 flex items-center justify-center">
                            <span className="text-white text-xs">
                              {user.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <span className="text-grey-900">{user.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-grey-700">{user.email}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          user.role === 'admin' 
                            ? 'bg-error-50 text-error-700' 
                            : user.role === 'manager'
                            ? 'bg-primary-50 text-primary-700'
                            : 'bg-grey-100 text-grey-700'
                        }`}>
                          {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1">
                          <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                            <Pencil className="w-4 h-4 text-grey-600" />
                          </button>
                          {user.role !== 'admin' && (
                            <button className="p-2 hover:bg-grey-100 rounded-lg transition-colors">
                              <Trash className="w-4 h-4 text-error-500" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
    }
  };

  const activeConfig = sections.find(s => s.id === activeSection);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Sidebar Navigation */}
      <div className="lg:col-span-1">
        <div className="bg-white rounded-xl border border-grey-200 p-2" style={{ boxShadow: 'var(--elevation-2)' }}>
          <nav className="space-y-1">
            {sections.map((section) => {
              const Icon = section.icon;
              const isActive = activeSection === section.id;
              
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-start gap-3 px-4 py-3 rounded-lg transition-colors text-left ${
                    isActive 
                      ? 'bg-primary-50 text-primary-700' 
                      : 'text-grey-700 hover:bg-grey-50'
                  }`}
                >
                  <Icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <div>
                    <p>{section.label}</p>
                    <p className={`text-xs mt-0.5 ${isActive ? 'text-primary-600' : 'text-grey-600'}`}>
                      {section.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Content Area */}
      <div className="lg:col-span-3">
        {renderContent()}
      </div>

      {/* Example Dialog (placeholder) */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New {activeConfig?.label}</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-grey-600">Form content would go here...</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button className="bg-primary-500 hover:bg-primary-700 text-white">
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
