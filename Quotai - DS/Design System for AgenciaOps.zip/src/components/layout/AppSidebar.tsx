import { LayoutDashboard, FolderKanban, Settings, DollarSign, Users, Package } from 'lucide-react';

interface AppSidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function AppSidebar({ currentPage, onNavigate }: AppSidebarProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'projects', label: 'Projects', icon: FolderKanban },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <aside className="w-64 h-screen bg-white border-r border-grey-200 fixed left-0 top-0 flex flex-col">
      {/* Logo/Header */}
      <div className="h-16 px-6 flex items-center border-b border-grey-200">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary-500 flex items-center justify-center">
            <DollarSign className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-primary-700">AgenciaOps</h2>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 py-4">
        <div className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`
                  w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors
                  ${isActive 
                    ? 'bg-primary-500 text-white' 
                    : 'text-grey-700 hover:bg-grey-50'
                  }
                `}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-grey-200">
        <div className="flex items-center gap-3 px-2">
          <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
            <span className="text-primary-700">AT</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-grey-900 truncate">Alex Thompson</p>
            <p className="text-grey-600 text-xs">Admin</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
