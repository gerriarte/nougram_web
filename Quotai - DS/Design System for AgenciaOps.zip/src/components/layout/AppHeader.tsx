import { Bell, Search } from 'lucide-react';

interface AppHeaderProps {
  title: string;
  description?: string;
}

export function AppHeader({ title, description }: AppHeaderProps) {
  return (
    <header className="h-16 bg-white border-b border-grey-200 fixed top-0 right-0 left-64 z-10">
      <div className="h-full px-6 flex items-center justify-between">
        {/* Left section */}
        <div>
          <h1>{title}</h1>
          {description && (
            <p className="text-grey-600 mt-0.5">{description}</p>
          )}
        </div>

        {/* Right section */}
        <div className="flex items-center gap-2">
          {/* Search */}
          <button className="p-2 hover:bg-grey-50 rounded-lg transition-colors">
            <Search className="w-5 h-5 text-grey-600" />
          </button>

          {/* Notifications */}
          <button className="p-2 hover:bg-grey-50 rounded-lg transition-colors relative">
            <Bell className="w-5 h-5 text-grey-600" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-error-500 rounded-full"></span>
          </button>

          {/* User profile */}
          <div className="ml-2 flex items-center gap-2 pl-2 border-l border-grey-200">
            <div className="w-8 h-8 rounded-full bg-primary-500 flex items-center justify-center">
              <span className="text-white">AT</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
