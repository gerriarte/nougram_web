import { useState } from 'react';
import { LoginPage } from './components/pages/LoginPage';
import { DashboardPage } from './components/pages/DashboardPage';
import { ProjectsPage } from './components/pages/ProjectsPage';
import { CreateQuotePage } from './components/pages/CreateQuotePage';
import { SettingsPage } from './components/pages/SettingsPage';
import { AppLayout } from './components/layout/AppLayout';
import { Toaster } from './components/ui/sonner';

type Page = 'login' | 'dashboard' | 'projects' | 'create-quote' | 'settings';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
    setCurrentPage('dashboard');
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  // Page titles and descriptions
  const pageConfig = {
    dashboard: {
      title: 'Dashboard',
      description: 'Overview of your agency performance'
    },
    projects: {
      title: 'Projects',
      description: 'Manage your quotes and projects'
    },
    'create-quote': {
      title: 'Create Quote',
      description: 'Build a new project quote'
    },
    settings: {
      title: 'Settings',
      description: 'Configure your agency operations'
    }
  };

  // Render login page if not authenticated
  if (!isAuthenticated) {
    return (
      <>
        <LoginPage onLogin={handleLogin} />
        <Toaster />
      </>
    );
  }

  // Get current page config
  const config = pageConfig[currentPage as keyof typeof pageConfig];

  return (
    <>
      <AppLayout
        currentPage={currentPage}
        onNavigate={handleNavigate}
        title={config.title}
        description={config.description}
      >
        {currentPage === 'dashboard' && <DashboardPage />}
        {currentPage === 'projects' && <ProjectsPage onNavigate={handleNavigate} />}
        {currentPage === 'create-quote' && <CreateQuotePage onNavigate={handleNavigate} />}
        {currentPage === 'settings' && <SettingsPage />}
      </AppLayout>
      <Toaster />
    </>
  );
}
